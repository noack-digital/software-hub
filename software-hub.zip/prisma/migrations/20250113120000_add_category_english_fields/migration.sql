-- AlterTable
ALTER TABLE "Category" ADD COLUMN     "nameEn" TEXT,
ADD COLUMN     "descriptionEn" TEXT;



