-- AlterTable
ALTER TABLE "Software" ADD COLUMN     "alternativesEn" TEXT,
ADD COLUMN     "descriptionEn" TEXT,
ADD COLUMN     "featuresEn" TEXT,
ADD COLUMN     "nameEn" TEXT,
ADD COLUMN     "notesEn" TEXT,
ADD COLUMN     "shortDescriptionEn" TEXT;
